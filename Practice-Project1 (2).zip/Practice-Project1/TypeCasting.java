package program.package1;

public class TypeCasting {
	
	public static void main(String[] args) {
		
		//implicit type casting
		char c1='A';
		int n1=c1;
		System.out.println(n1); //output:65
		
		//explicit type casting
		int n2=65;
		char c2= (char)n2;
		System.out.println(c2); //output:A
	}

}
